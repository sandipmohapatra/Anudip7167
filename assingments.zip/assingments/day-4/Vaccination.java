package com.anudip.example;

import java.util.Scanner;

abstract class Vaccine{
	int firstDose=0;
	int secondDose=0;
	void firstDose(String n,int age) 
	//first dose method is checking that user eligible or not 
	{
		if((n.equalsIgnoreCase("Indian"))&&(age>=18)) {
		System.out.println("Your First dose Successfilly Done.Now you have to pay 250 Rs");
		firstDose=1;
		}
		else {
			System.out.println("You are not eligible for the first dose");
			if((age<18)&&(n.equalsIgnoreCase("Indian"))) {
				System.out.println("Under age");
			}
			else if(!(n.equalsIgnoreCase("Indian"))&&(age>=18)) {
				System.out.println("You are not Indian");
			}
			else {
				System.out.println("You are not Indian and also you are Under age.");
			}
		}
	}
	//second dose method is checking that user eligible or not 
	void secondDose() {
		if(firstDose==1) {
			System.out.println("Your Second dose Successfilly Done");
			secondDose=1;
		}
		else {
			System.out.println("You are not eligible for the second dose");
		}
		
		
	}
	abstract void boosterDose();	
	
}

class VaccinationSucessful extends Vaccine{
	
	
	
	
	//booster dose method is checking that user eligible or not 
	void boosterDose() {
		if((firstDose==1)&&(secondDose==1)){
			System.out.println("Your Booster dose Successfilly Done");
			
		}
		else {
		System.out.println("You are not eligible for the Booster dose");
		}
	}
		
}

public class Vaccination{

	public static void main(String[] args) {
		
		VaccinationSucessful v=new VaccinationSucessful();
		
		//senario 1
		v.firstDose( "indian",18);//call firstDose method for checking eligible or not
		//senario 2
		v.secondDose();//call secondDose method for checking eligible or not
		//senario 3 
		v.boosterDose();//call boosterDose method for checking eligible or not
			
		
		

	}
	}


