package com.anudip.example;
//Animal.java
 class Animall {
 public void makeSound() {
     System.out.println("The animal makes a sound.");
 }
}
//Cat.java
class Catt extends Animall {
 @Override
 public void makeSound() {
     System.out.println("The Cat meows");
 }
}

//Cat.java
class Dogg extends Animall {
@Override
public void makeSound() {
   System.out.println("The dog barks");
}
}
public class Assignment2 {

	public static void main(String[] args) {
		 Animall animal = new Animall();
	        Catt cat = new Catt();
	        Dogg dog = new Dogg();
	        animal.makeSound();
	        cat.makeSound();
	        dog.makeSound();
	}

}
