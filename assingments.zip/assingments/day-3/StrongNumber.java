package basicprograms;

import java.util.Scanner;

public class StrongNumber {

	static void  calculateStrongNumber(int num)
	{
	int rem,sum=0,temp;
	temp=num;
	while(num>0)
	{
		
		rem=num%10; 
		//invoke factorial() 
		int f=factorial(rem);
		sum+=f;   
		num=num/10;
	}
	
	if(sum==temp)
	{
	System.out.println(temp+" is a strong number");
	}
	else
		System.out.println(temp+" is not a strong number");

	}
	
	static int factorial(int n)
	{
		int fact=1;
		for(int i=1;i<=n;i++)
		{
		fact*=i; //fact=fact*i
		}
       return fact;
	}
	
	public static void main(String[] args) {
		calculateStrongNumber(145);

	}

}
