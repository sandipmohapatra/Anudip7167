package oops_concept;

class User
{
int id;
String name;


public User(int id,String name)
{
	//super();//will parent class default constructor 
	this.id=id;
	this.name=name;
	
}

}
class Employee extends User{
double salary;


	public Employee (int id, String name,double salary) {
		super(id, name); //invoke immediate parent class parameterized constructor
	    this.salary=salary;
	}

	
	double calculateAnnualSalary()
	{
		return salary*12;
	}


	
	}



public class InheritanceDemo {

	public static void main(String[] args) {
		Employee p=new Employee (101,"ram",20000);
        System.out.println("Annual Salary: "+p.calculateAnnualSalary());
		
	}

}
