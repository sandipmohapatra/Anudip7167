import java.util.Scanner;

public class MaxBetweenTwoNumbers {
    public static void main(String[] args) {
        
        int num1=10,num2=30;
        
        int max = (num1 > num2) ? num1 : num2;
        
        System.out.println("The maximum between " + num1 + " and " + num2 + " is: " + max);
        
        scanner.close();
    }
}
