package com.anudip.example;

public class Assignment {

	public static void main(String[] args) {
		 
		int num=12, n=2, bitStatus;

	    /* Right shift num, n times and perform bitwise AND with 1 */
	    bitStatus = (num >> n) & 1;

	    System.out.println(n+" bit of "+num+" is Set("+bitStatus+")");
	}
	}


