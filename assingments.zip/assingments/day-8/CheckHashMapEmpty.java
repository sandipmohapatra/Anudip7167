package assignments;

import java.util.HashMap;
import java.util.Map;

public class CheckHashMapEmpty {

	public static void main(String[] args) {
		   // Create a new HashMap instance with keys of type String and values of type Integer
        Map<String, Integer> hashMap = new HashMap<>();

        // Associate values with keys using the put() method
        hashMap.put("one", 1);
        hashMap.put("two", 2);
        hashMap.put("three", 3);

        // Check if the HashMap is empty
        boolean isEmpty = hashMap.isEmpty();
        System.out.println("Is the HashMap empty? " + isEmpty);

        // Clear the HashMap
        hashMap.clear();

        // Check again if the HashMap is empty
        isEmpty = hashMap.isEmpty();
        System.out.println("Is the HashMap empty after clearing? " + isEmpty);
    }
}





