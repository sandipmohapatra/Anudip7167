package assignments;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class CricketScoresMap {

	public static void main(String[] args) {
		// Create a Map instance with keys of type String (player name) and values of type Integer (score)
        Map<String, Integer> cricketScores = new HashMap<>();

        // Populate the Map with player names and scores
        cricketScores.put("Virat Kohli", 112);
        cricketScores.put("Rohit Sharma", 89);
        cricketScores.put("Shikhar Dhawan", 45);
        cricketScores.put("KL Rahul", 67);
        cricketScores.put("Rishabh Pant", 34);

        // Search for a player's name and display their score
        String playerNameToSearch = "Rohit Sharma";
        if (cricketScores.containsKey(playerNameToSearch)) {
            int playerScore = cricketScores.get(playerNameToSearch);
            System.out.println(playerNameToSearch + "'s score: " + playerScore);
        } else {
            System.out.println(playerNameToSearch + " not found in the map.");
        }
    }
}



