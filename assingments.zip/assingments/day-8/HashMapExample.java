package assignments;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		  // Create a new HashMap instance with keys of type String and values of type Integer
        Map<String, Integer> hashMap = new HashMap<>();

        // Associate values with keys using the put() method
        hashMap.put("one", 1);
        hashMap.put("two", 2);
        hashMap.put("three", 3);

        // Print the contents of the HashMap
        System.out.println("HashMap: " + hashMap);

	}

}
