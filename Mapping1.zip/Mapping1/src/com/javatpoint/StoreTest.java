package com.javatpoint;  
  
import java.util.HashMap;  
import org.hibernate.*;
import org.hibernate.cfg.Configuration;  


public class StoreTest {  
public static void main(String[] args) {  
 
	Configuration cfg=new Configuration();
	SessionFactory sf=cfg.configure().buildSessionFactory();
	Session ss=sf.openSession();
	 
Transaction t=ss.beginTransaction();  
  
HashMap<String,String> map1=new HashMap<String,String>();  
map1.put("java is a programming language","John Milton");  
map1.put("java is a platform","Ashok Kumar");  
  
HashMap<String,String> map2=new HashMap<String,String>();  
map2.put("servlet technology is a server side programming","John Milton");  
map2.put("Servlet is an Interface","Ashok Kumar");  
map2.put("Servlet is a package","Rahul Kumar");  
  
Question question1=new Question("What is java?","Alok",map1);  
Question question2=new Question("What is servlet?","Jai Dixit",map2);  
  
ss.persist(question1);  
ss.persist(question2);  
  
t.commit();  
ss.close();  
System.out.println("successfully stored");  
}  
}  