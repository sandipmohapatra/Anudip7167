package com.javatpoint;  
import java.util.Iterator;  
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration; 
  
public class Fetch {  
public static void main(String[] args) {  
	Configuration cfg=new Configuration();
	SessionFactory sf=cfg.configure().buildSessionFactory();
	Session ss=sf.openSession();
      
    Query query=ss.createQuery("from Employee e");  
    List<Employee> list=query.list(); 
        
    Iterator<Employee> itr=list.iterator();  
    while(itr.hasNext()){  
     Employee emp=itr.next();  
     System.out.println(emp.getEmployeeId()+" "+emp.getName()+" "+emp.getEmail());  
     
     
     Address address=emp.getAddress();  
     System.out.println(address.getAddressLine1()+" "+address.getCity()+" "+  
        address.getState()+" "+address.getCountry()+" "+address.getPincode());  
    }  
  
    ss.close();  
    System.out.println("success");  
}  
}  